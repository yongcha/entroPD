Research for k-Anonymity Privacy Preserving Data Mining based on Entropy
=======

# Contents

- [Process](#process)

- [Functions](#functions)

- [Team Members](#team-members)


# <a name="process"></a>Process
![Process](./process.PNG)


# <a name="functions"></a>Functions

- `parda`
- `cpselec`
- `rpaclass`
- `lanode`
- `qigrp`
- `eclass`
- `resume`
- `plot.resume`


# <a name="team-members"></a>Team Members
- "Yong Cha" <yong.stat@gmail.com>
